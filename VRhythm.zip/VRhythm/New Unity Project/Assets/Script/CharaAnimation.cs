﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CharaAnimation : MonoBehaviour
{
	Animator animator;
	//CharacterStatus status;
    Vector3 prePosition;
    bool isDown = false;
    bool attacked = false;
    bool running = false;
    public bool damage_count = true;
    public bool attack_count;
    public bool chest = false;

    public bool IsRunning()
    {
        return running;
    }

    public void TrueFalseRunning(bool temp)
    {
        this.running = temp;
    }

    public bool IsAttacked()
    {
        return attacked;
    }

    public void SetDamageCount(bool temp)
    {
        damage_count = temp;
    }

    public bool GetDamageCount()
    {
        return damage_count;
    }

    public void SetChest(bool temp)
    {
        chest = temp;
    }

    public bool GetChest()
    {
        return this.chest;
    }

    

    // Start is called before the first frame update
    void Start()
    {
        animator = GetComponent<Animator>();
        //status = GetComponent<CharacterStatus>();

        prePosition = transform.position;                       //最初のPlayerの位置
        SetChest(false);
    }

    // Update is called once per frame
    void Update()
    {
        Vector3 delta_position = transform.position - prePosition;                  //現在位置 - 初期の位置
        //animator.SetFloat("walk", delta_position.magnitude / Time.deltaTime);

        //if (attacked && !status.attacking)
        //{
        //    attacked = false;
        //}
        //animator.SetBool("Attacking", (!attacked && status.Attacking()));

        //if (!isDown && status.died)
        //{
        //    isDown = true;
        //    animator.SetTrigger("Down");
        //}

        prePosition = transform.position;
    }
}
