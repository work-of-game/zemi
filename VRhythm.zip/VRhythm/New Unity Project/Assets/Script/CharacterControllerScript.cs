﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CharacterControllerScript : MonoBehaviour
{

    public Animator animator;
    public CharacterController controller;
    Rigidbody rb;

    public float speed;
    public float jumpspeed;
    public float rotateSpeed;
    public float gravity;
    public float attackRange = 1.5f;

    bool hohuku_flag = false;

    Vector3 targetDirection;
    Vector3 moveDirection = Vector3.zero;
    //CharacterStatus status;

    // Start is called before the first frame update
    void Start()
    {
        speed = 20.0f;
        //status = GetComponent<CharacterStatus>();

        moveControl();
        RotationControl();

        controller.Move(moveDirection * Time.deltaTime);
        rb = GetComponent<Rigidbody>();
        controller.height = 0.1f;
        controller.radius = 0.2f;
        controller.center = new Vector3(0, 0.15f, 0.05f);
    }

    // Update is called once per frame
    void Update()
    {
        moveControl();
        RotationControl();
        controller.Move(moveDirection * Time.deltaTime);
        if (Input.GetKeyDown(KeyCode.K))
        {
           // status.TrueAttacking();
        }

    }

    void moveControl()
    {
        float v = Input.GetAxisRaw("Vertical") * speed;                 //上下の入力
        float h = Input.GetAxisRaw("Horizontal") * speed;               //右左の入力

        Vector3 forward = Vector3.Scale(Camera.main.transform.forward, new Vector3(1, 0, 1));
        Vector3 right = Camera.main.transform.right;

        targetDirection = h * right + v * forward;


        if (controller.isGrounded)
        {
            moveDirection = targetDirection * speed;

            if (Input.GetButton("Jump"))
            {
                animator.SetTrigger("jump");
                StartCoroutine("JumpCoroutine");
            }
        }
        else
        {
            float temp = moveDirection.y;
            moveDirection = Vector3.Scale(targetDirection, new Vector3(1, 0, 1)).normalized;
            moveDirection *= speed;
            moveDirection.y = temp - gravity * Time.deltaTime;
        }

        if (Input.GetKeyDown(KeyCode.C))
        {
            controller.height = 0.1f;
            controller.radius = 0.05f;
            controller.center = new Vector3(0, 0.05f, 0.05f);
            animator.SetBool("hohuku", true);
            hohuku_flag = true;
        }
        if (Input.GetKeyDown(KeyCode.X))
        {
            controller.height = 0.1f;
            controller.radius = 0.2f;
            controller.center = new Vector3(0, 0.15f, 0.05f);
            animator.SetBool("hohuku", false);
            hohuku_flag = false;
        }

        if (!hohuku_flag)
        {
            if (v > 0f || v < 0f || h > 0f || h < 0f)
            {
                animator.SetFloat("walk", 10.0f);
                rb.MovePosition(transform.position + new Vector3(v, 0, h));
                //animator.SetBool("Running", true);
            }
            else
            {
                animator.SetFloat("walk", 0f);
                //animator.SetBool("Running", false);
            }
        }

        else
        {
            if (v > 0f || v < 0f || h > 0f || h < 0f)
            {
                animator.SetFloat("hohuku_walk", 10.0f);
                rb.MovePosition(transform.position + new Vector3(v, 0, h));
                //animator.SetBool("Running", true);
            }
            else
            {
                animator.SetFloat("hohuku_walk", 0f);
                //animator.SetBool("Running", false);
            }
        }
    }



    void RotationControl()
    {
        Vector3 rotateDirection = moveDirection;
        rotateDirection.y = 0;

        if (rotateDirection.sqrMagnitude > 0.01)
        {
            float step = rotateSpeed * Time.deltaTime;
            Vector3 newDir = Vector3.Slerp(transform.forward, rotateDirection, step);
            transform.rotation = Quaternion.LookRotation(newDir);
        }
    }

    IEnumerator JumpCoroutine()
    {
        yield return new WaitForSeconds(0.3f);
        moveDirection.y = jumpspeed;
    }
}
